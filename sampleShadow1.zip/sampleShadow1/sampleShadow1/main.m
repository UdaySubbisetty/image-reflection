//
//  main.m
//  sampleShadow1
//
//  Created by Uday on 26/12/17.
//  Copyright © 2017 rutherford.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
